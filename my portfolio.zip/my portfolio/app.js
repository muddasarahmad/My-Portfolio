let submit = document.getElementById("submit");
submit.onclick = function(){
   if(floatingInput != " "){
    document.write("<h1>Submitted Successfully ! </h1><br>");
    let y = document.write("<h2>Our Team will reply you within a few hours.</h2>");
    }
}

// document.createElement(<a href = "C:\Users\web&app(50)\Desktop\my portfolio\index.html " ><button>Back</button></a>);

